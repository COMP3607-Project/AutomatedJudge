/*Student ID: 816033413
  Student Name: Jason Balroop
  Course: COMP 2603 - Assignment 1*/
  package comp3607project;
import java.util.ArrayList;
public class LuggageManifest{
    private ArrayList<LuggageSlip> slips;
    
    public LuggageManifest(){
        slips = new ArrayList<LuggageSlip>();
    }
    
    public String addLuggage(Passenger p, Flight f){
        int numLuggage=p.getNumLuggage();
        int allowedLuggage=f.getAllowedLuggage(p.getCabinClass());
        int counter=0; // counter to make the loop add each passenger's luggage to array
        
        double excessLuggageCost=0;
        excessLuggageCost=getExcessLuggageCost(numLuggage,allowedLuggage);
        
        String label="$";
        label+=excessLuggageCost;
        
        while(counter<numLuggage){
            
            if(excessLuggageCost>0)
                slips.add(new LuggageSlip(p,f,label));
            else
                slips.add(new LuggageSlip(p,f));
            
            counter++;
        }
        
        String output="";
        if(numLuggage>0)
            output=p.toString()+"\nPieces Added: ("+numLuggage+"). Excess Cost: "+label;
        else
            output=p.toString()+"\nNo Luggage to add.";
        
        return output;
    }
    
    public double getExcessLuggageCost(int numPieces, int numAllowedPieces){
        int excessPieces=0;
        double cost=0;
        if(numPieces>numAllowedPieces){
            excessPieces = numPieces - numAllowedPieces;
            cost=excessPieces*35;
        }
        return cost;
    }
    
    public String getExcessLuggageCostByPassenger(String passportNumber){
        
        for(int i=0;i<slips.size();i++){
            if(slips.get(i).hasOwner(passportNumber)){
                String label=slips.get(i).getLabel();
                if(label=="") // if label is empty then no cost
                    return "No Cost";
                else
                    return label;
            }
        }
        return "No Cost"; // if the function is not returned by here the passportNumber isn't found;
    }
    
    public String toString(){
        
        String s = "LUGGAGE MANIFEST:\n";
        
        for (int i=0;i<slips.size();i++){
            s+=slips.get(i).toString()+"\n";
        }
        
        return s;
    }
} 