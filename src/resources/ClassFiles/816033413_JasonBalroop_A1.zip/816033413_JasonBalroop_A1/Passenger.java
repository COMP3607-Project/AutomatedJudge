/*Student ID: 816033413
  Student Name: Jason Balroop
  Course: COMP 2603 - Assignment 1*/
  package comp3607project;
import java.util.Random;
public class Passenger{
    private String passportNumber;
    private String flightNo;
    private String firstName;
    private String lastName;
    private int numLuggage;
    private char cabinClass;
    
    public Passenger(String passportNumber, String firstName, String lastName, String flightNo){
        this.passportNumber = passportNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.flightNo = flightNo;
        assignRandomCabinClass();
        numLuggage=assignRandomLuggage();
    }
    
    public void assignRandomCabinClass(){
        Random r = new Random();
        int cabin=r.nextInt(4);
        if(cabin==0)
            cabinClass = 'F';
        else if (cabin==1)
            cabinClass = 'B';
        else if (cabin==2)
            cabinClass = 'P';
        else
            cabinClass = 'E';
    }
    
    public int assignRandomLuggage(){
        Random r = new Random();
        int luggage=r.nextInt(4);
        return luggage;
    }
    
    public String getPassportNumber(){
        return passportNumber;
    }
    
    public String getFlightNo(){
        return flightNo;
    }
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public int getNumLuggage(){
        return numLuggage;
    }
    
    public char getCabinClass(){
        return cabinClass;
    }
    
    public String toString(){
        String s="PP NO. "+getPassportNumber()+" NAME: "+getFirstName().charAt(0)+"."+getLastName()+" NUMLUGGAGE: "+getNumLuggage()+" CLASS: "+getCabinClass();
        return s;
    }
}