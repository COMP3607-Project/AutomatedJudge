/*Student ID: 816033413
  Student Name: Jason Balroop
  Course: COMP 2603 - Assignment 1*/
  package comp3607project;
public class LuggageSlip{
    private Passenger owner;
    private static int luggageSlipIDCounter=1;
    private String luggageSlipID;
    private String label;
    
    public LuggageSlip(Passenger p, Flight f){
        owner=p;
        makeLuggageSlipID(p,f);
        label="";
    }
    
    public LuggageSlip(Passenger p, Flight f, String label){
        owner=p;
        makeLuggageSlipID(p,f);
        this.label=label;
    }
    
    private void makeLuggageSlipID(Passenger p, Flight f){ // Method to use within the constructor
        luggageSlipID=f.getFlightNo()+"_"+p.getLastName()+"_"+luggageSlipIDCounter;
        luggageSlipIDCounter++;
    }
    
    public boolean hasOwner(String passportNumber){
        if(owner.getPassportNumber()==passportNumber)
            return true;
        else
            return false;
    }
    
    public Passenger getOwner(){
        return owner;
    }
    
    public int getLuggageSlipIDCounter(){
        return luggageSlipIDCounter;
    }
    
    public String getLuggageSlipID(){
        return luggageSlipID;
    }
    
    public String getLabel(){
        return label;
    }
        
    public String toString(){
        Passenger p = getOwner();
        String s=p.toString();
        s=getLuggageSlipID()+" "+s+" "+label;
        return s;
    }
}