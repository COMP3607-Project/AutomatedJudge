/*Student ID: 816033413
  Student Name: Jason Balroop
  Course: COMP 2603 - Assignment 1*/

import java.io.File;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.io.FileNotFoundException;
public class LuggageManagementSystem{
    
    private static ArrayList<Flight> flights = new ArrayList<Flight>(); 
    private static LocalDateTime d = LocalDateTime.of(2023,1,23,10,00,00);
    public static void main (String[] args){
        
        try{
            File flightFile = new File("FlightList.txt");
            Scanner scanner = new Scanner (flightFile);
            String flightData="";
            while(scanner.hasNextLine()){ /* adding each flight into an array of flights */
                flightData=scanner.nextLine();
                String[] flightInfo=flightData.split(" ");
                flights.add(new Flight(flightInfo[0],flightInfo[1],flightInfo[2],d));
            }
        }
        catch(Exception e){
            System.out.println("Flight error");
        }
        
        try{
            File passengerFile = new File("PassengerList.txt");
            Scanner scanner2 = new Scanner (passengerFile);
            String passengerData="";
            Passenger p;
            while(scanner2.hasNextLine()){
                passengerData=scanner2.nextLine();
                String[] passengerInfo=passengerData.split(" ");
                
                Random r = new Random();
                int plane=r.nextInt(3);
                String flightNo="";
                if(plane==0) // Randomly Assigning a plane to each passenger
                    flightNo="BW600";
                else if(plane==1)
                    flightNo="FL210";
                else
                    flightNo="HT490";
                
                p = new Passenger(passengerInfo[0],passengerInfo[1],passengerInfo[2],flightNo);
                for(int i=0;i<flights.size();i++){ 
                    if(flights.get(i).getFlightNo().equals(p.getFlightNo())){
                        System.out.println(flights.get(i).checkInLuggage(p)+"\n");
                    }
                }
            }
            for(int i=0;i<flights.size();i++){
                System.out.println(flights.get(i).printLuggageManifest());
            }
        }
        catch(Exception e){
            System.out.println("Passenger error");
        }
    }
}