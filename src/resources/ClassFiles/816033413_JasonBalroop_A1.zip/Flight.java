/*Student ID: 816033413
  Student Name: Jason Balroop
  Course: COMP 2603 - Assignment 1*/

import java.time.LocalDateTime;
public class Flight{
    private String flightNo;
    private String destination;
    private String origin;
    private LocalDateTime flightDate;
    private LuggageManifest manifest;
    
    public Flight(String flightNo, String destination, String origin, LocalDateTime flightDate){
        this.flightNo=flightNo;
        this.destination=destination;
        this.origin=origin;
        this.flightDate=flightDate;
        manifest = new LuggageManifest();
    }
    
    public String checkInLuggage(Passenger p){
        if(p.getFlightNo().equals(flightNo)){
            String outcome=manifest.addLuggage(p,this);
            return outcome;
        }
        else
            return "Invalid flight";
    }
    
    public String printLuggageManifest(){
        return manifest.toString();
    }
    
    public static int getAllowedLuggage(char cabinClass){
        int allowed=0;
        if(cabinClass=='F')
            allowed=3;
        else if(cabinClass=='B')
            allowed=2;
        else if(cabinClass=='P')
            allowed=1;
        return allowed;
    }
    
    public String getFlightNo(){
        return flightNo;
    }
    
    public String getDestination(){
        return destination;
    }
    
    public String getOrigin(){
        return origin;
    }
    
    public LocalDateTime getFlightDate(){
        return flightDate;
    }
    
    public LuggageManifest getManifest(){
        return manifest;
    }
    
    public String toString(){
        String s=getFlightNo()+" DESTINATION: "+getDestination()+" ORIGIN: "+getOrigin()+" "+getFlightDate();
        return s;
    }
}