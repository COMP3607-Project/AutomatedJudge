// 816031597
package comp3607project;
public class LuggageSlip 
{
    //attributes
    private Passenger owner;
    private static int luggageSlipIDCounter = 1; //class variables are shared among all objects
    private String luggageSlipID;
    private String label;
     
    //constructors
    public LuggageSlip(Passenger p, Flight f)
    {
        owner = p;
        luggageSlipID = (p.getFlightNo() + "_" + p.getLastName() + "_" + luggageSlipIDCounter);
        label = "";
        
        luggageSlipIDCounter++;
    }
    
    public LuggageSlip(Passenger p, Flight f, String label)
    {
        owner = p;
        luggageSlipID = (p.getFlightNo() + "_" + p.getLastName() + "_" + luggageSlipIDCounter);
        this.label = label;
        
        luggageSlipIDCounter++;
    }
    
    //methods
    public boolean hasOwner (String passportNumber)
    {
        String ppNo = owner.getPassportNumber();
        
        if (ppNo.equals(passportNumber)) //ie. if (owner.getPassportNumber() == passportNumber)
            return true;
        else
            return false;
    }
    
    public String toString()
    {
        char fnLetter = owner.getFirstName().charAt(0);
        
        return (luggageSlipID + " PP NO:" + owner.getPassportNumber() + " NAME:" + fnLetter + "." + 
                owner.getLastName() + " NUMLUGGAGE:" + owner.getNumLuggage() + " CLASS:" + owner.getCabinClass() + " " + label); 
        
    }
    
    //accessors
    public Passenger getOwner()
    {
        return owner;
    }
    
    public int getLuggageSlipIDCounter()
    {
        return luggageSlipIDCounter;
    }
    
    public String getLuggageSlipID()
    {
        return luggageSlipID;
    }
    
    public String getLabel()
    {
        return label;
    }
}