// 816031597
package comp3607project;
import java.util.Random;
public class Passenger 
{
    // attributes
    private String passportNumber;
    private String flightNo;
    private String firstName;
    private String lastName;
    private int numLuggage;
    private char cabinClass; 
    
    //constructor
    public Passenger(String passportNumber, String firstName, String lastName, String flightNo)
    {
        this.passportNumber = passportNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.flightNo = flightNo;
        setNumLuggage();
        assignRandomCabinClass();
    }
     
    //methods    
    public void assignRandomCabinClass() 
    {
        Random r = new Random();
        int num = r.nextInt(4); //generate random number bewteen 0 and 3
        
        if (num == 0)
            cabinClass = 'F';
        else
            if (num == 1)
                cabinClass = 'B';
            else
                if (num == 2)
                    cabinClass = 'P';
                else
                    cabinClass = 'E';
    }
      
    public String toString()
    {
        //get first letter of first name
        char fnLetter = getFirstName().charAt(0);
        
        return ("PP NO:" + getPassportNumber() + " NAME:" + fnLetter + "." + 
                getLastName() + " NUMLUGGAGE:" + getNumLuggage() + " CLASS:" + getCabinClass());             
    }
    
    //private helper method that sets numLuggage value
    private void setNumLuggage()
    {
        Random r = new Random();
        numLuggage = r.nextInt(4); //generates random number bewteen 0 and 3
    }
    
    //accessors
    public String getPassportNumber()
    {
        return passportNumber;
    }
    
    public String getFlightNo()
    {
        return flightNo;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public int getNumLuggage()
    {
        return numLuggage;
    }
    
    public char getCabinClass()
    {
        return cabinClass;
    }
}