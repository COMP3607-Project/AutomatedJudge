// 816031597
package comp3607project;
import java.io.File;
import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;
import java. time.LocalDateTime;
public class LuggageManagementSystem
{
    public static void main(String args[]) throws Exception
    {
        LocalDateTime d = LocalDateTime.of(2023,1,23,20,00,00);
        
        File input1 = new File("FlightList.txt");
        Scanner scan1 = new Scanner(input1);
        Flight[] flight = new Flight[50];
        
        File input2 = new File("PassengerList.txt");
        Scanner scan2 = new Scanner(input2);
        Passenger p;
        
        int x=0;
        while (scan1.hasNextLine()){ //store flights
            String flNo = scan1.next();
            String flDes = scan1.next();
            String flOr = scan1.next();
            
            flight[x] = new Flight(flNo, flDes, flOr, d);
            System.out.println(flight[x]);
            
            x+=1;
            scan1.hasNextLine();
        }
        
        while(scan2.hasNextLine()){
            String ppNo = scan2.next();
            String pFN = scan2.next();
            String pLN = scan2.next();
            
            Random r = new Random(); //randomly assign passengers to flights
            int num = r.nextInt(x);
            
            p = new Passenger(ppNo, pFN, pLN, flight[num].getFlightNo());
            System.out.println(p);
            
            scan2.hasNextLine();
            System.out.println(flight[num].checkInLuggage(p));
        }
        
        int i=0;
        while (flight[i] != null){
            System.out.println(flight[i].printLuggageManifest());
            i+=1;
        }
    }
}
