// 816031597
import java.util.ArrayList;
public class LuggageManifest
{
    private ArrayList<LuggageSlip> slips; //stores multiple ArrayList objects
     
    // constructor
    public LuggageManifest()
    {
        slips = new ArrayList<LuggageSlip>();
    }

    // methods
    public String addLuggage(Passenger p, Flight f)
    {   int numPieces = p.getNumLuggage();
        int numAllowedPieces = f.getAllowedLuggage(p.getCabinClass()); 
        double extraCost=0.0;
        String costLabel;
        LuggageSlip newSlip;
        
        if (numPieces<= numAllowedPieces) 
             newSlip = new LuggageSlip(p, f);
        else { //has extra luggage
            extraCost = getExcessLuggageCost(numPieces, numAllowedPieces);
            costLabel = "$" + extraCost;
            newSlip = new LuggageSlip(p, f, costLabel);
        }
         
        slips.add(newSlip); //add new slip to ArrayList
        
        if (numPieces != 0)
            return (p.toString() + "\n" + "Pieces Added:(" + numPieces + ")" +
                    " Excess Cost:$" + extraCost);
        else
            return (p.toString() + "\n" + "No Luggage to add.");
    }
    
    public double getExcessLuggageCost(int numPieces, int numAllowedPieces)
    {
        int extra=0;
        
        if (numPieces > numAllowedPieces)
            extra = (numPieces - numAllowedPieces);
            
        return (extra* 35.0);
    }
    
    public String getExcessLuggageCostByPassenger(String passportNumber)
    {
        String ppNo;
        Double cost= 0.00;
        
        for(LuggageSlip a : slips){ //for each entry in ArrayList
            Passenger p = a.getOwner();
            ppNo = p.getPassportNumber();
    
            if (ppNo.equals(passportNumber))     
                cost = getExcessLuggageCost(p.getNumLuggage(), Flight.getAllowedLuggage(p.getCabinClass())); //use class name to call class method!
        }
         
        if (cost != 0.00)
            return "$" + cost;
        else
            return "No Cost";
    }
    
    public String toString()
    {
        //return slips.toString();
        String aggr = "";
        
        for(LuggageSlip a: slips){
            aggr += a + "\n";
        }
        
        return aggr;
    }
    
    //accessor
    public ArrayList getLuggageSlip()
    {
        return slips;
    }
}