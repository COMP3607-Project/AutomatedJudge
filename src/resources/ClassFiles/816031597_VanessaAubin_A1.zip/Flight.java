// 816031597
import java.time.LocalDateTime;
public class Flight
{
    // attributes
    private String flightNo;
    private String destination;
    private String origin;
    private LocalDateTime flightDate;
    private LuggageManifest manifest;
 
    // constructor
    public Flight(String flightNo, String destination, String origin, LocalDateTime flightDate)
    {
        this.flightNo = flightNo;
        this.destination = destination;
        this.origin = origin;
        this.flightDate = flightDate;
        manifest = new LuggageManifest();
    }
     
    // methods
    public String checkInLuggage(Passenger p)
    {
        String pFlightNo = p.getFlightNo();
        String flight = getFlightNo();
        
        if(pFlightNo.equals(flight)) 
            return getManifest().addLuggage(p, this);
        else
            return ("Invalid Flight");
    }
    
    public String printLuggageManifest()
    {
        //string rep. of the manifest!!
        return manifest.toString();
    } 
    
    //class method!
    public static int getAllowedLuggage(char cabinClass)
    {   int numLug = 0;
        
        if (cabinClass == 'F')
            numLug = 3;
        else
            if (cabinClass == 'B')
                numLug = 2;
            else
                if(cabinClass == 'P')
                    numLug = 1;
                else
                    numLug = 0; 
                    
        /*switch(cabinClass){
            case 'F':
                numLug = 3;
            case 'B':    
                numLug = 2;
            case 'P':
                numLug = 1;
            case 'E':
               numLug = 0;   
        }*/
        
        return numLug;
    }
    
    public String toString()
    {
        return(getFlightNo() + " DESTINATION:" + getDestination() + " ORIGIN:" + getOrigin() + " " + getFlightDate());
    }
    
    //accessors
    public String getFlightNo()
    {
        return flightNo;
    }
    
    public String getDestination()
    {
        return destination;
    }
    
    public String getOrigin()
    {
        return origin;
    }
    
    public LocalDateTime getFlightDate()
    {
        return flightDate;
    }
    
    public LuggageManifest getManifest()
    {
        return manifest;
    }
}